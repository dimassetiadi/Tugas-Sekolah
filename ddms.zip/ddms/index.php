<!DOCTYPE html> 
<html> 
<head>     
<title>Pendaftaran Siswa Baru | SMK Coding</title> 
</head> 
 
<body>     
<header>         
<h3>Pendaftaran Siswa Baru</h3>         
<h1>SMK Coding</h1>     
</header> 
 
    <h4>Menu</h4>     
    <nav>         
    <ul>             
    <li><a href="form-daftar.php">Daftar Baru</a></li>             
    <li><a href="list-siswa.php">Pendaftar</a></li>         
    </ul>     
    </nav> 
 
    </body>
</html>