<?php

class User_model{
private $nama = 'Dimas Sudarsonic';

public function getUser()
    {
        return $this->nama;
    }


}