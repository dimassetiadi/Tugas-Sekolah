<div class="container">
    <h1 class="mt-4">About Me</h1>
    <img src="<?= BASEURL; ?>/IMGG/1.jpg" alt="Dimas Sudarsono" width="200" class="rounded-circle shadow">
    <p> Halo, Nama Saya <?= $data['nama']; ?> , Umur saya <?= $data['umur']; ?>, saya seorang <?= $data['pekerjaan'];?> </p>
</div>